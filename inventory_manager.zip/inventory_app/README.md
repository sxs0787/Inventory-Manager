# Inventory Manager

A simple desktop app for managing product/inventory data, backed by a
local SQLite database, with the ability to sync data in from Excel
files whenever you need to.

## What it does

- Stores your product data in a local database file (`inventory.db`) —
  no server, no cloud account needed.
- Lets you view, search, add, edit, and delete products in a table.
- **Sync from Excel**: point it at an `.xlsx`/`.xls`/`.csv` file and it
  will import the rows. Products are matched by **SKU** — if a SKU
  already exists in the database, that row gets *updated*; if it's
  new, it gets *added*. This means you can re-run the sync any time
  your Excel file changes (e.g. weekly stock counts) without creating
  duplicate entries.
- **Column mapping**: the first time you sync a file, a dialog lets you
  confirm which Excel column maps to which field (SKU, Name, Quantity,
  etc.). It tries to guess automatically based on common header names
  (like "SKU", "Product Code", "Qty", "Unit Cost"...). Your choices are
  remembered for next time.
- Rows at or below their reorder level are highlighted in the table
  so low stock is easy to spot.

## Setup

1. Make sure you have Python 3.9+ installed.
2. Install the dependencies:

   ```
   pip install -r requirements.txt
   ```

   (Tkinter, used for the window itself, ships with Python on Windows
   and macOS. On Linux, if you get a `No module named tkinter` error,
   install it via your package manager, e.g. `sudo apt install python3-tk`.)

3. Run the app:

   ```
   python app.py
   ```

   This creates `inventory.db` in the same folder the first time you
   run it — that file is your database. Back it up like any other
   important file.

## Using it

- **Sync from Excel...** — choose your Excel/CSV file, confirm the
  column mapping, and it imports/updates your product list.
- **Add Product** — manually add a single item.
- **Edit Selected** (or double-click a row) — edit a product.
- **Delete Selected** — remove a product.
- **Search** box — filters by SKU, name, category, or supplier as you type.
- Click a column header to sort by that column.

## Expected Excel columns

Any column names work, since you map them yourself on first sync, but
these fields are used:

| Field          | Required | Notes                                  |
|----------------|----------|-----------------------------------------|
| SKU            | Yes      | Unique product identifier               |
| Product Name   | Yes      | —                                        |
| Category       | No       | —                                        |
| Quantity       | No       | Defaults to 0 if blank                  |
| Unit Price     | No       | Defaults to 0 if blank                  |
| Supplier       | No       | —                                        |
| Reorder Level  | No       | Used to flag low stock in the table     |

## Files

- `app.py` — the UI (Tkinter)
- `database.py` — SQLite storage layer
- `excel_sync.py` — Excel/CSV reading + column-mapping logic
- `inventory.db` — created on first run; your actual data lives here

## Extending it

Some natural next steps if you want to grow this later:
- Export the current table back out to Excel (`df.to_excel(...)`)
- Add a "low stock report" view or CSV export
- Track purchase orders or sales alongside inventory
- Multi-user support via a networked database (e.g. Postgres) instead
  of SQLite, if more than one person needs to use it at once
